<?php

$baseUrl = '/atendelab/public/';